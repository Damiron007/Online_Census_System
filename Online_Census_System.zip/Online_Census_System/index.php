<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>index.php</title>
<!-- TemplateEndEditable -->
<style type="text/css">
<!--
body {
	background-color: #000;
}
a:link {
	color: #FFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFF;
}
a:hover {
	text-decoration: none;
	color: #F00;
}
a:active {
	text-decoration: none;
	color: #FFF;
}
a {
	font-size: 14px;
	font-weight: bold;
}
body,td,th {
	color: #00F;
	font-size: 14px;
}
.style1 {color: #CCFF00}
.style2 {color: #FFFFFF}
.style3 {font-size: 16px}
-->
</style>
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
</head>

<body bgcolor="#FFFFFF">
<div align="center">
  <p><strong>
    <marquee align="left">
    </marquee>
  </strong></p>
  <strong><marquee align="left">
  <h1>WELCOME TO ONLINE CENSUS MANAGEMENT SYSTEM </h1>
  </marquee>
  </strong>
  <h2>&nbsp;</h2>
  <h2><strong align="left"><a href="login.php" class="style3">LOGIN</a></strong> <span class="style2">(for  staff members)</span></h2>
  <h2>&nbsp;</h2>
  <h3 class="style1"><strong>THIS SITE WAS DESIGNED </strong></h3>
  <h3 class="style1"><strong>BY </strong></h3>
  <h2 align="center"><span class="style1"><strong>ONUMAJURU  RITA  .C.</strong> - <strong>REG NO. 2014514460</strong><br />
    <strong>NTAGBU WILLIAMS</strong> - <strong>REG NO. 2014514444</strong> </span></h2>
  <h3 align="center" class="style1">&nbsp;</h3>
  <h3>&nbsp;</h3>
  <p>&nbsp;</p>
<p>&nbsp;</p>
</div>
</body>
</html>