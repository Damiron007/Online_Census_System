<?php require_once('Connections/censusmgtdb.php'); ?>
<?php
$maxRows_RsBirth_record = 50;
$pageNum_RsBirth_record = 0;
if (isset($_GET['pageNum_RsBirth_record'])) {
  $pageNum_RsBirth_record = $_GET['pageNum_RsBirth_record'];
}
$startRow_RsBirth_record = $pageNum_RsBirth_record * $maxRows_RsBirth_record;

mysql_select_db($database_censusmgtdb, $censusmgtdb);
$query_RsBirth_record = "SELECT * FROM birth_recordtb";
$query_limit_RsBirth_record = sprintf("%s LIMIT %d, %d", $query_RsBirth_record, $startRow_RsBirth_record, $maxRows_RsBirth_record);
$RsBirth_record = mysql_query($query_limit_RsBirth_record, $censusmgtdb) or die(mysql_error());
$row_RsBirth_record = mysql_fetch_assoc($RsBirth_record);

if (isset($_GET['totalRows_RsBirth_record'])) {
  $totalRows_RsBirth_record = $_GET['totalRows_RsBirth_record'];
} else {
  $all_RsBirth_record = mysql_query($query_RsBirth_record);
  $totalRows_RsBirth_record = mysql_num_rows($all_RsBirth_record);
}
$totalPages_RsBirth_record = ceil($totalRows_RsBirth_record/$maxRows_RsBirth_record)-1;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>BIRTH RECORD</title>
<!-- TemplateEndEditable -->
<style type="text/css">
<!--
body {
			font-size: 15px;
			color: #343d44;
			font-family: "segoe-ui", "open-sans", tahoma, arial;
			padding: 0;
			margin: 0;
		}
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;
		}

		h1 {
			margin: 25px auto 0;
			text-align: center;
			text-transform: uppercase;
			font-size: 17px;
		}

		table td {
			transition: all .5s;
		}
		
		/* Table */
		.data-table {
			border-collapse: collapse;
			font-size: 14px;
			min-width: 537px;
		}

		.data-table th, 
		.data-table td {
			border: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.data-table caption {
			margin: 7px;
		}

		/* Table Header */
		.data-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}

		/* Table Body */
		.data-table tbody td {
			color: #353535;
		}
		.data-table tbody td:first-child,
		.data-table tbody td:nth-child(4),
		.data-table tbody td:last-child {
			text-align: right;
		}

		.data-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.data-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
		}

		/* Table Footer */
		.data-table tfoot th {
			background-color: #e5f5ff;
			text-align: right;
		}
		.data-table tfoot th:first-child {
			text-align: left;
		}
		.data-table tbody td:empty
		{
			background-color: #ffcccc;
		}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFFFFF;
}
a:hover {
	text-decoration: none;
	color: #FF0000;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
}
a {
	font-weight: bold;
}
.style2 {color: #0000FF}
.style3 {color: #FFFFFF}
.style4 {color: #FFFFFF; font-weight: bold; }
-->
</style>
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
</head>

<body bgcolor="#FFFFFF">
<div align="center">
  <table width="1002" height="350" border="0" bgcolor="#FFFFFF">
    <!--DWLayoutTable-->
    <tr>
      <td height="48" colspan="3" align="left" valign="middle" bgcolor="#0000FF"><a href="home.php">HOME</a> <span class="style3">|</span> <a href="about.php">ABOUT PROJECT </a><span class="style3">|</span><a href="birth_count.php"> BIRTH COUNT </a> <span class="style3">| </span><a href="death_count.php">DEATH COUNT </a> <span class="style3">|</span> <a href="census_count.php">CENSUS COUNT </a><span class="style3"> | <a href="census_summary.php">CENSUS RECORD</a> | </span> <a href="index.php">LOGOUT</a></td>
    </tr>
    <tr>
      <td height="124" colspan="3" valign="top"><div align="center"><img src="banner.jpg" width="994" height="120" /></div></td>
    </tr>
    <tr>
      <td width="753" height="122" valign="top"><form id="form1" name="form1" method="post" action="">
        <h2 align="center">BIRTH RECORD </h2>
          </form>
        <p align="center">This captures the birth of every child in the country for each year. This forms part of the census collection. </p>
      </td>
      <td width="3">&nbsp;</td>
      <td width="233" rowspan="3" valign="top" bgcolor="#0000CC"><p>&nbsp;</p></td>
    </tr>
    <tr>
      <td height="50" valign="top"><table border="1">
  <!--DWLayoutTable-->
  <tr>
    <td width="120" height="20"><strong>Serial number</strong></td>
    <td width="180"><strong>Child name</strong></td>
    <td width="139"><strong>Gender</strong></td>
    <td width="173"><strong>Date of birth</strong></td>
    <td width="187"><strong>Parents name</strong></td>
    <td width="189"><strong>Year of capture</strong></td>
  </tr>
  <?php do { ?>
    <tr>
      <td height="20"><?php echo $row_RsBirth_record['Serial_number']; ?></td>
      <td><?php echo $row_RsBirth_record['Child_name']; ?></td>
      <td><?php echo $row_RsBirth_record['Gender']; ?></td>
      <td><?php echo $row_RsBirth_record['Date_of_birth']; ?></td>
      <td><?php echo $row_RsBirth_record['Parents_name']; ?></td>
      <td><?php echo $row_RsBirth_record['Year_of_capture']; ?></td>
    </tr>
    <?php } while ($row_RsBirth_record = mysql_fetch_assoc($RsBirth_record)); ?>
	<tr><td height="20" colspan="6" valign="top"> <p>&nbsp;</p>
	  <p align="center"><a href="birth_count.php"><span class="style2">Back to Birth Count </span></a></p>
	  <p>&nbsp;</p></td>
	  </tr>
<tr>
      <td height="37" colspan="6" valign="middle" bgcolor="#0000FF"><div align="center" class="style4">Copyright &copy; 2018 All rights reserved</div></td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($RsBirth_record);
?>