<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>WELCOME TO ONLINE MANAGEMENT SYSTEM</title>
<!-- TemplateEndEditable -->
<style type="text/css">
<!--
body {
	background-color: #999;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFF;
}
a:hover {
	text-decoration: none;
	color: #F00;
}
a:active {
	text-decoration: none;
	color: #FFF;
}
a {
	font-size: 14px;
	font-weight: bold;
}
.style3 {color: #FFFFFF; font-weight: bold; }
-->
</style>
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
</head>

<body bgcolor="#FFFFFF">
<div align="center">
  <table width="1002" height="518" border="0" bgcolor="#FFFFFF">
    <!--DWLayoutTable-->
    <tr>
      <td height="48" colspan="3" align="left" valign="middle" bgcolor="#0000FF"><a href="home.php">HOME</a> <span class="style3">|</span> <a href="about.php">ABOUT PROJECT </a><span class="style3">|</span><a href="birth_count.php"> BIRTH COUNT </a> <span class="style3">| </span><a href="death_count.php">DEATH COUNT </a> <span class="style3">|</span> <a href="census_count.php">CENSUS COUNT </a><span class="style3"> | <a href="census_summary.php">CENSUS RECORD</a> | </span> <a href="index.php">LOGOUT</a></td>
    </tr>
    <tr>
      <td height="124" colspan="3" valign="top"><img src="banner.jpg" width="994" height="120" /></td>
    </tr>
    <tr>
      <td width="750" height="617" valign="top" bgcolor="#FFFFFF"><form id="form1" name="form1" method="post" action="">
        <h2>WELCOME TO ONLINE  CENSUS MANAGEMENT SYSTEM </h2>
          <p align="justify">Census management system is one of the technologies adopted by NPC in the capture of the population of the country. The application helps the commision in arriving at the actual figures of Nigerians living in the country. </p>
          <p align="justify">It also helps the Government in their decision making and planning. </p>
          <ol start="1" type="1">
            <li>NATIONAL COUNCIL ON POPULATION       MANAGEMENT (NCPM) which is the highest policy making body headed by the       President was inaugurated on 7th&nbsp;July, 2008 by the President.</li><br/>
            <li>POPULATION ADVISORY GROUP (PAG)       which is headed by the Chairman, National Population Commission was       inaugurated on 22nd&nbsp;September, 2008 by the Chairman. It consists of 15       members representing civil society organizations, traditional and       religious leaders and other eminent citizens in the field of Population       Development.</li>
          </ol>
          <p align="justify">&nbsp;</p>
      </form>
        </td>
      <td width="5">&nbsp;</td>
      <td width="233" valign="top" bgcolor="#0000CC"><p><strong><font color="#FFFFFF">Our Objective</font></strong></p>
        <p><font color="#FFFFFF">1. Creating a robust database that will help keep information about all the citizens in the country </font></p>
        <p><font color="#FFFFFF">2. Create a robust application where national informaton for decision making and implementation can be easily accessed. </font></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      <p>&nbsp;</p>        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td height="37" colspan="3" valign="middle" bgcolor="#0000FF"><div align="center" class="style3">Copyright &copy; 2018 All rights reserved</div></td>
    </tr>
  </table>
</div>
</body>
</html>