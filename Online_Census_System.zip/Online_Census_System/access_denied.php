<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unauthorized login</title>
<style type="text/css">
<!--
a {
	font-size: 14px;
	color: #FFF;
	font-weight: bold;
}
a:hover {
	color: #F00;
	text-decoration: underline;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
.style1 {color: #FFFFFF}
.style2 {font-size: 20px}
-->
</style></head>

<body>
<p>&nbsp;</p>
<div align="center">
  <table width="764" height="347" border="1">
    <!--DWLayoutTable-->
    <tr>
      <td width="754" height="374" valign="top" bgcolor="#000066"><h1 align="center" class="style1">  RESTRICTED PAGE </h1>
        <p align="center" class="style1">&nbsp;</p>
        <h2 align="center"><font color="#FFFFFF">YOU ARE NOT PERMITTED TO VIEW THIS PAGE</font> </h2>
        <p>&nbsp;</p>
        <p align="center"><a href="login.php" class="style2">Login </a></p>
        <p align="center">&nbsp;</p>
      <p align="center">&nbsp;</p>        <p align="center">&nbsp;</p></td>
    </tr>
  </table>
</div>
<p>&nbsp;</p>
</body>
</html>