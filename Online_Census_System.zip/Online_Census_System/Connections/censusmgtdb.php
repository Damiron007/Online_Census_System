<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_censusmgtdb = "localhost";
$database_censusmgtdb = "censusmgtdb";
$username_censusmgtdb = "root";
$password_censusmgtdb = "David";
$censusmgtdb = mysql_pconnect($hostname_censusmgtdb, $username_censusmgtdb, $password_censusmgtdb) or trigger_error(mysql_error(),E_USER_ERROR); 
?>