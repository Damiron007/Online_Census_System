<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>ABOUT CENSUS MANAGEMENT SYSTEM PROJECT</title>
<!-- TemplateEndEditable -->
<style type="text/css">
<!--
body {
	background-color: #999;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFF;
}
a:hover {
	text-decoration: none;
	color: #F00;
}
a:active {
	text-decoration: none;
	color: #FFF;
}
a {
	font-size: 14px;
	font-weight: bold;
}
.style3 {color: #FFFFFF; font-weight: bold; }
-->
</style>
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
</head>

<body bgcolor="#FFFFFF">
<div align="center">
  <table width="1002" height="518" border="0" bgcolor="#FFFFFF">
    <!--DWLayoutTable-->
    <tr>
      <td height="48" colspan="3" align="left" valign="middle" bgcolor="#0000FF"><a href="home.php">HOME</a> <span class="style3">|</span> <a href="about.php">ABOUT PROJECT </a><span class="style3">|</span><a href="birth_count.php"> BIRTH COUNT </a> <span class="style3">| </span><a href="death_count.php">DEATH COUNT </a> <span class="style3">|</span> <a href="census_count.php">CENSUS COUNT </a><span class="style3"> | <a href="census_summary.php">CENSUS RECORD</a> | </span> <a href="index.php">LOGOUT</a></td>
    </tr>
    <tr>
      <td height="124" colspan="3" valign="top"><img src="banner.jpg" width="994" height="120" /></td>
    </tr>
    <tr>
      <td width="750" height="617" valign="top" bgcolor="#FFFFFF"><form id="form1" name="form1" method="post" action="">
        <h2>ABOUT ONLINE  CENSUS MANAGEMENT SYSTEM </h2>
          <p align="justify">In 1989, Nigeria set up the independent National Population Commission (NPC) to undertake a long awaited, free of political tampering census. The head of the NPC separated the country into 7 census areas. Someone with no natal or marital connection to the area headed each area. The NPC followed current guidelines on conducting a census and held pretests and a rehearsal. It hired about 800,000 enumerators. Finally, in 3 days in November 1991, they collected census data from households where people were instructed to remain between 6-18 o'clock. This request along with other points helped to depoliticize this census. </p>
          <p align="justify">For example, population size would no longer determine distribution of government expenditures. Further the census questionnaire did not contain any questions to politicized topics mainly ethnic group, language, or religion. The results of the census revealed that population size was actually 88.5 million instead of the 1991 population estimates of 112-123 million. Lawmakers and leaders in several states have already called for recounts. In the past, census counts were inflated to increase revenue and due to ethnic conflict. Past population estimates have been based on the 1963 census which, despite its questionable reliability, was deemed more accurate than that of 1973. The 1963 count was officially 56 million, but the UN Demographic Yearbook reported it to be 46 million. Yet, now that the results of the much more reliable 1991 census are known, even 46 million was probably too high. The 1991 count indicated that the 1963 count was more likely between 36-41 million which was quite compatible with the 1953 count. </p>
          <p align="justify">Some population specialists fear that this much smaller population size will result in the government and people downplaying population policies and family planning. Indeed 1 political leader already told men to marry more wives and have more children. Yet the population may reach 120 million by 2000 at its current 3% rate of natural increase.</p>
          <p>&nbsp;</p>
      </form>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      <p><a href="Upload File/PHP File upload/index.php"></a></p>        <p>&nbsp;</p></td>
      <td width="5">&nbsp;</td>
      <td width="233" valign="top" bgcolor="#0000CC"><p><strong><font color="#FFFFFF">Our Objective</font></strong></p>
        <p><font color="#FFFFFF">1. Creating a robust database that will help keep information about all the citizens in the country </font></p>
        <p><font color="#FFFFFF">2. Create a robust application where national informaton for decision making and implementation can be easily accessed. </font></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      <p>&nbsp;</p>        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td height="37" colspan="3" valign="middle" bgcolor="#0000FF"><div align="center" class="style3">Copyright &copy; 2018 All rights reserved</div></td>
    </tr>
  </table>
</div>
</body>
</html>