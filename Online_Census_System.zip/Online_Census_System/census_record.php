<?php require_once('Connections/censusmgtdb.php'); ?>
<?php
$maxRows_RsCensus_record = 100;
$pageNum_RsCensus_record = 0;
if (isset($_GET['pageNum_RsCensus_record'])) {
  $pageNum_RsCensus_record = $_GET['pageNum_RsCensus_record'];
}
$startRow_RsCensus_record = $pageNum_RsCensus_record * $maxRows_RsCensus_record;

mysql_select_db($database_censusmgtdb, $censusmgtdb);
$query_RsCensus_record = "SELECT * FROM individual_tb";
$query_limit_RsCensus_record = sprintf("%s LIMIT %d, %d", $query_RsCensus_record, $startRow_RsCensus_record, $maxRows_RsCensus_record);
$RsCensus_record = mysql_query($query_limit_RsCensus_record, $censusmgtdb) or die(mysql_error());
$row_RsCensus_record = mysql_fetch_assoc($RsCensus_record);

if (isset($_GET['totalRows_RsCensus_record'])) {
  $totalRows_RsCensus_record = $_GET['totalRows_RsCensus_record'];
} else {
  $all_RsCensus_record = mysql_query($query_RsCensus_record);
  $totalRows_RsCensus_record = mysql_num_rows($all_RsCensus_record);
}
$totalPages_RsCensus_record = ceil($totalRows_RsCensus_record/$maxRows_RsCensus_record)-1;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>CENSUS RECORD</title>
<!-- TemplateEndEditable -->
<style type="text/css">
<!--
body {
			font-size: 15px;
			color: #343d44;
			font-family: "segoe-ui", "open-sans", tahoma, arial;
			padding: 0;
			margin: 0;
		}
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;
		}

		h1 {
			margin: 25px auto 0;
			text-align: center;
			text-transform: uppercase;
			font-size: 17px;
		}

		table td {
			transition: all .5s;
		}
		
		/* Table */
		.data-table {
			border-collapse: collapse;
			font-size: 14px;
			min-width: 537px;
		}

		.data-table th, 
		.data-table td {
			border: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.data-table caption {
			margin: 7px;
		}

		/* Table Header */
		.data-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}

		/* Table Body */
		.data-table tbody td {
			color: #353535;
		}
		.data-table tbody td:first-child,
		.data-table tbody td:nth-child(4),
		.data-table tbody td:last-child {
			text-align: right;
		}

		.data-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.data-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
		}

		/* Table Footer */
		.data-table tfoot th {
			background-color: #e5f5ff;
			text-align: right;
		}
		.data-table tfoot th:first-child {
			text-align: left;
		}
		.data-table tbody td:empty
		{
			background-color: #ffcccc;
		}
a:link {
	color: #FFFFFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFFFFF;
}
a:hover {
	text-decoration: none;
	color: #FF0000;
}
a:active {
	text-decoration: none;
	color: #FFFFFF;
}
a {
	font-weight: bold;
}
.style3 {color: #0000FF}
.style4 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
<!-- TemplateBeginEditable name="head" -->
<!-- TemplateEndEditable -->
</head>

<body bgcolor="#FFFFFF">
<div align="center">
  <table width="1002" height="200" border="0" bgcolor="#FFFFFF">
    <!--DWLayoutTable-->
    <tr>
      <td width="996" height="48" align="left" valign="middle" bgcolor="#0000FF"><a href="home.php">HOME</a> <span class="style3">|</span> <a href="about.php">ABOUT PROJECT </a><span class="style3">|</span><a href="birth_count.php"> BIRTH COUNT </a> <span class="style3">| </span><a href="death_count.php">DEATH COUNT </a> <span class="style3">|</span> <a href="census_count.php">CENSUS COUNT </a><span class="style3"> | <a href="census_summary.php">CENSUS RECORD</a> | </span> <a href="index.php">LOGOUT</a></td>
    </tr>
    <tr>
      <td height="124" valign="top"><img src="banner.jpg" width="994" height="120" /></td>
    </tr>
    <tr>
      <td height="20" valign="top" bgcolor="#FFFFFF"><div align="center"><strong>CENSUS RECORD </strong></div></td>
    </tr>
    <table border="1">
      <!--DWLayoutTable-->
  <tr>
    <td width="162" height="18"><strong>Serial number</strong></td>
    <td width="194"><strong>Full names</strong></td>
    <td width="200"><strong>Date of birth</strong></td>
    <td width="220"><strong>House address</strong></td>
    <td width="197"><strong>Phone  number</strong></td>
    <td width="145"><strong>Email address</strong></td>
    <td width="154"><strong>Gender</strong></td>
    <td width="142"><strong>Tribe</strong></td>
    <td width="156"><strong>Religion</strong></td>
    <td width="194"><strong>State of origin</strong></td>
    <td width="212"><strong>Name of parents</strong></td>
    <td width="227"><strong>Number of children</strong></td>
    <td width="190"><strong>Marital status</strong></td>
    <td width="175"><strong>Occupation</strong></td>
    <td width="197"><strong>Working status</strong></td>
    <td width="204"><strong>Year of capture</strong></td>
  </tr>
  <?php do { ?>
    <tr>
      <td height="18"><?php echo $row_RsCensus_record['Serial_no']; ?></td>
      <td><?php echo $row_RsCensus_record['Full_names']; ?></td>
      <td><?php echo $row_RsCensus_record['Date_of_birth']; ?></td>
      <td><?php echo $row_RsCensus_record['House_address']; ?></td>
      <td><?php echo $row_RsCensus_record['Phone_number']; ?></td>
      <td><?php echo $row_RsCensus_record['Email_address']; ?></td>
      <td><?php echo $row_RsCensus_record['Gender']; ?></td>
      <td><?php echo $row_RsCensus_record['Tribe']; ?></td>
      <td><?php echo $row_RsCensus_record['Religion']; ?></td>
      <td><?php echo $row_RsCensus_record['State_of_origin']; ?></td>
      <td><?php echo $row_RsCensus_record['Name_of_parents']; ?></td>
      <td><?php echo $row_RsCensus_record['Number_of_children']; ?></td>
      <td><?php echo $row_RsCensus_record['Marital_status']; ?></td>
      <td><?php echo $row_RsCensus_record['Occupation']; ?></td>
      <td><?php echo $row_RsCensus_record['Working_status']; ?></td>
      <td><?php echo $row_RsCensus_record['Year_of_capture']; ?></td>
    </tr>
    <?php } while ($row_RsCensus_record = mysql_fetch_assoc($RsCensus_record)); ?>
	<tr>
	<td height="37" colspan="16" valign="middle" ><div align="center"> <a href="census_count.php" class="style3"><span class="style3">Back to Census Count</span></a></div></td>
	</tr>
 <tr>
      <td height="37" colspan="16" valign="middle" bgcolor="#0000FF"><div align="center" class="style4">Copyright &copy; 2018 All rights reserved</div></td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($RsCensus_record);
?>