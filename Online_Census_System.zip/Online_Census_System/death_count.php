<?php require_once('Connections/censusmgtdb.php'); ?>
<?php
	$query = "Select Max(Serial_number) From death_recordtb";
	$returnD = mysql_query($query);
	$result = mysql_fetch_assoc($returnD);
	Print mysql_error();
	$maxRows = $result['Max(Serial_number)'];
  if(empty($maxRows)){
	    $lastRow = $maxRows + 1;       
    }else{
		$lastRow = $maxRows + 0001 ;
    }
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($QUERY_STRING) && strlen($QUERY_STRING) > 0) 
  $MM_referrer .= "?" . $QUERY_STRING;
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO death_recordtb (Serial_number, Date_of_birth, Date_of_death, Gender, Name_of_deceased, State_of_origin, Year_of_capture) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['Serial_number'], "int"),
                       GetSQLValueString($_POST['Date_of_birth'], "text"),
                       GetSQLValueString($_POST['Date_of_death'], "text"),
                       GetSQLValueString($_POST['Gender'], "text"),
                       GetSQLValueString($_POST['Name_of_deceased'], "text"),
                       GetSQLValueString($_POST['State_of_origin'], "text"),
                       GetSQLValueString($_POST['Year_of_capture'], "text"));

  mysql_select_db($database_censusmgtdb, $censusmgtdb);
  $Result1 = mysql_query($insertSQL, $censusmgtdb) or die(mysql_error());

  $insertGoTo = "death_count.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- TemplateBeginEditable name="doctitle" -->
<title>DEATH COUNT</title>
<!-- TemplateEndEditable -->
<style type="text/css">
<!--
body {
	background-color: #999;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
a:link {
	color: #FFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFF;
}
a:hover {
	text-decoration: none;
	color: #F00;
}
a:active {
	text-decoration: none;
	color: #FFF;
}
a {
	font-size: 14px;
	font-weight: bold;
}
.style3 {color: #FFFFFF; font-weight: bold; }
.style6 {color: #0000FF}
-->
</style>
<!-- TemplateBeginEditable name="head" --><!-- TemplateEndEditable -->
</head>

<body bgcolor="#FFFFFF">
<div align="center">
  <table width="1002" height="518" border="0" bgcolor="#FFFFFF">
    <!--DWLayoutTable-->
    <tr>
      <td height="48" colspan="3" align="left" valign="middle" bgcolor="#0000FF"><a href="home.php">HOME</a> <span class="style3">|</span> <a href="about.php">ABOUT PROJECT </a><span class="style3">|</span><a href="birth_count.php"> BIRTH COUNT </a> <span class="style3">| </span><a href="death_count.php">DEATH COUNT </a> <span class="style3">|</span> <a href="census_count.php">CENSUS COUNT </a><span class="style3"> | <a href="census_summary.php">CENSUS RECORD</a> | </span> <a href="index.php">LOGOUT</a></td>
    </tr>
    <tr>
      <td height="124" colspan="3" valign="top"><img src="banner.jpg" width="994" height="120" /></td>
    </tr>
    <tr>
      <td width="750" height="617" valign="top" bgcolor="#FFFFFF"><form id="form1" name="form1" method="post" action="">
        <h2 align="center">DEATH RECORD </h2>
          <p align="justify">This form helps  in the collection of people who died recently </p>
          </form>
        <form method="post" name="form2" action="<?php echo $editFormAction; ?>">
          <table align="center">
            <tr valign="baseline">
              <td nowrap align="right">Serial number:</td>
              <td><input type="text" readonly="True" name="Serial_number" value= "<?php if(!empty($lastRow)){ echo sprintf("%04d", $lastRow); }?>" size="32"></td>
            </tr>
            <tr valign="baseline">
              <td nowrap align="right">Date of birth:</td>
              <td><input type="date" name="Date_of_birth" value="" size="32"></td>
            </tr>
            <tr valign="baseline">
              <td nowrap align="right">Date of death:</td>
              <td><input type="date" name="Date_of_death" value="" size="32"></td>
            </tr>
            <tr valign="baseline">
              <td nowrap align="right">Gender:</td>
              <td><select name="Gender" id="Gender">
			  <option value="">Select...</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
			  </select></td>
            </tr>
            <tr valign="baseline">
              <td nowrap align="right">Name of deceased:</td>
              <td><input type="text" name="Name_of_deceased" value="" size="32"></td>
            </tr>
            <tr valign="baseline">
              <td nowrap align="right">State of origin:</td>
              <td><select name="State_of_origin" id="State_of_origin">
			  <option value="">Select...</option>
              <option value="Abia">Abia</option>
              <option value="Adamawa">Adamawa</option>
			  <option value="Akwa Ibom">Akwa Ibom</option>
              <option value="Anambra">Anambra</option>
			  <option value="Bauchi">Bauchi</option>
              <option value="Bayelsa">Bayelsa</option>
			  <option value="Benue">Benue</option>
              <option value="Borno">Borno</option>
			  <option value="Cross River">Cross River</option>
              <option value="Delta">Delta</option>
			  <option value="Ebonyi">Ebonyi</option>
              <option value="Edo">Edo</option>
			  <option value="Ekiti">Ekiti</option>
              <option value="FCT">FCT</option>
			  <option value="Gombe">Gombe</option>
              <option value="Imo">Imo</option>
			  <option value="Jigawa">Jigawa</option>
              <option value="Kaduna">Kaduna</option>
			  <option value="Kano">Kano</option>
              <option value="Katsina">Katsina</option>
			  <option value="Kebbi">Kebbi</option>
              <option value="Kogi">Kogi</option>
			  <option value="Kwara">Kwara</option>
              <option value="Lagos">Lagos</option>
			  <option value="Nasarawa">Nasarawa</option>
              <option value="Niger">Niger</option>
			  <option value="Ogun">Ogun</option>
              <option value="Ondo">Ondo</option>
			  <option value="Osun">Osun</option>
              <option value="Oyo">Oyo</option>
			  <option value="Plateau">Plateau</option>
              <option value="Rivers">Rivers</option>
			  <option value="Sokoto">Sokoto</option>
              <option value="Taraba">Taraba</option>
			  <option value="Yobe">Yobe</option>
              <option value="Zamfara">Zamfara</option>
			  </select></td>
            </tr>
            <tr valign="baseline">
              <td nowrap align="right">Year of capture:</td>
              <td><input type="text" name="Year_of_capture" value="" size="32"></td>
            </tr>
            <tr valign="baseline">
              <td nowrap align="right">&nbsp;</td>
              <td><input type="submit" value="Save record"></td>
            </tr>
          </table>
          <p align="center">
            <input type="hidden" name="MM_insert" value="form2">
            <a href="death_record.php" class="none style6"></a></p>
        </form>
		<div align="center"><a href="death_record.php" class="style3"><span class="style3 style6">View Death Record </span> </a></div></td>
     
      <td width="233" valign="top" bgcolor="#0000CC"><p><strong><font color="#FFFFFF">Our Objective</font></strong></p>
        <p><font color="#FFFFFF">1. Creating a robust database that will help keep information about all the citizens in the country </font></p>
        <p><font color="#FFFFFF">2. Create a robust application where national informaton for decision making and implementation can be easily accessed. </font></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
      <p>&nbsp;</p>        <p>&nbsp;</p></td>
    </tr>
    <tr>
      <td height="37" colspan="3" valign="middle" bgcolor="#0000FF"><div align="center" class="style3">Copyright &copy; 2018 All rights reserved</div></td>
    </tr>
  </table>
</div>
</body>
</html>